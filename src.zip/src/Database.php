<?php
namespace Itb;


class Database
{
    const DB_NAME = 'irishwomensrugby';
    const DB_USER = 'root';
    const DB_PASS = 'pass';
    const DB_HOST = 'localhost:3306';

    // the private connection property
    private $connection;

    /*
     * create a new MySQL db connection
     */
   public function __construct()
    {
        try {
            $dsn = 'mysql:dbname=' . self::DB_NAME . ';host=' . self::DB_HOST;
            $this->connection = new \PDO(
                $dsn,
                self::DB_USER,
                self::DB_PASS
            );
        } catch (\Exception $e){
            print '<pre>';
            var_dump($e);
        }
    }

    /**
     * @return mixed
     */
    public function getConnection()
    {
        return $this->connection;
    }

}