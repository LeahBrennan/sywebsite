<?php
namespace Itb;


class MainController2
{
    private $twig;

    public function __construct($twig)
    {
        $this->twig = $twig;
    }

    public function editProductAction($id)
    {
        $productRepository = new ProductRepository();
        $productRepository->getOne($id);

        $template = 'edit.html.twig';
        $args = [
            'product' => $product
        ];

        $html = $this->twig->render($template, $args);
        print $html;
    }

    public function processProductUpdateAction($id, $quantity, $description, $price)
    {
        
		
		$template = 'confirmUpdateData.html.twig';
        $args = [
            'id' => $id,
            'quantity' => $quantity,
            'description' => $description,
			'price' => $price
        ];

        $html = $this->twig->render($template, $args);
        print $html;
		

    }

}