<?php

namespace Itb;


class ProductRepository
{
    /**
     * @var \PDO
     */
    private $connection;

    public function __construct()
    {
        $db = new Database();
        $this->connection = $db->getConnection();
    }

    public function dropTable()
    {
        $sql = "DROP TABLE IF EXISTS products";
        $this->connection->exec($sql);
    }

    public function createTable()
    {

        $sql = "
            CREATE TABLE IF NOT EXISTS products(
            id INT NOT NULL primary key auto_increment,
            description text,
            price INT,
			quantity INT)
        ";
        $this->connection->exec($sql);
    }

    public function insertProduct(Product $p)
    { 
	$quantity = $p->getQuantity();
	$description = $p->getDescription();
	$price = $p->getPrice();
	
	
        // Prepare INSERT statement to SQLite3 file db
        $sql = 'INSERT INTO products (quantity, description, price) 
			VALUES (:quantity, :description, :price)';
        $stmt = $this->connection->prepare($sql);

        // Bind parameters to statement variables
        $stmt->bindParam(':description', $description);
        $stmt->bindParam(':quantity', $quantity);
		$stmt->bindParam(':price', $price);

        // Execute statement
        $stmt->execute();
    }

    public function getAll()
    {
        $sql = 'SELECT * FROM products';

        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        $stmt->setFetchMode(\PDO::FETCH_CLASS, 'Itb\\Product');

        $products = $stmt->fetchAll();

        return $products;
    }


    public function getOne($id)
    {
        $sql = 'SELECT * FROM products WHERE id = :id';

        $stmt = $this->connection->prepare($sql);
        $stmt->bindParam(':id', $id);
		
		
		

        // Execute statement
        $stmt->execute();
        $stmt->setFetchMode(\PDO::FETCH_CLASS, 'Itb\\Product');

        $product = $stmt->fetch();

        return $product;


    }
	public function update($id,$description, $price, $quantity, $title)
	{
		$sql = "UPDATE products SET description = :description, price = :price, quantity =:quantity WHERE id =:id";
		
		$stmt = $this->connection->prepare($sql);
		
		$stmt->bindParam(':description', $description);
		$stmt->bindParam(':price', $price);
        $stmt->bindParam(':quantity', $quantity);
		$stmt->bindParam(':id', $id);
		
		$noError =$stmt->execute();
		
		return $noError;
	}


    public function deleteAll()
    {
        $sql = 'DELETE * FROM products';

        $stmt = $this->connection->exec($sql);
    }





	}