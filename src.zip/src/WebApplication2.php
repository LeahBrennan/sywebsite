<?php

namespace Itb;


class WebApplication
{
    const PATH_TO_TEMPLATES = __DIR__ . '/../views';
    private $mainController2;

    public function __construct()
    {
        $twig = new \Twig\Environment(new \Twig_Loader_Filesystem(self::PATH_TO_TEMPLATES));
        $this->mainController2 = new MainController2($twig);
    }

    public function run()
    {
        $action = filter_input(INPUT_GET, 'action');
        if(empty($action)){
            $action = filter_input(INPUT_POST, 'action');
        }

        switch($action){
            case 'processProductUpdate':
                $id = filter_input(INPUT_POST, 'id');
                $description = filter_input(INPUT_POST, 'description');
                $price = filter_input(INPUT_POST, 'price');
                $this->mainController2->processProductUpdateAction($id, $description, $price);
                break;

            case 'editProduct':
                $id = filter_input(INPUT_GET, 'id');
                $this->mainController2->editProductAction($id);
                break;

          case 'home':
          default:
	      $this->mainController->homeAction();
        }
    }

}