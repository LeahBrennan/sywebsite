<?php

namespace Itb;


class ShoppingCart
{
    private $quantity;
	private $id;
    private $description;
    private $price;
	

    /**
     * @return mixed
     */
	public function getQuantity()
	{
		return $this ->quantity;
	}
	public function setQuantity()
	{
		return $this -> quantity;
	}
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $id
     */
    public function setId($id)
    {
        $this->id = $Id;
    }

    /**
     * @return mixed
     */
    public function getDescription()
    {
        return $this->description;
    }

    /**
     * @param mixed $description
     */
    public function setDescription($description)
    {
        $this->description = $description;
    }

    /**
     * @return mixed
     */
    public function getPrice()
    {
        return $this->price;
    }

    /**
     * @param mixed $price
     */
    public function setPrice($price)
    {
        $this->price = $price;
    }



}