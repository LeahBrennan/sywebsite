<?php


namespace Itb;


class StaffRepository
{
    /**
     * @var \PDO
     */
    private $connection;

    public function __construct()
    {
        $db = new Database();
        $this->connection = $db->getConnection();
    }

    public function dropTable()
    {
        $sql = "DROP TABLE IF EXISTS staff";
        $this->connection->exec($sql);
    }

    public function createTable()
    {
      

        $sql = "
            CREATE TABLE IF NOT EXISTS staff (
			id INT NOT NULL primary key auto_increment,
            employeename text
			department text,
			)
        ";

        $this->connection->exec($sql);
    }

    public function insertStaff(Staff $s)
    {
		$id = $s->getId();
		$employeename = $s->getEmployeeName();
		$department = $s->getDepartment();
		
        // Prepare INSERT statement to SQLite3 file db
        $sql = 'INSERT INTO staff (id, employeename, department) 
			VALUES ( :id, :employeename, :department)';
        $stmt = $this->connection->prepare($sql);

        // Bind parameters to statement variables
        $stmt->bindParam(':id', $id);
        $stmt->bindParam(':employeename', $employeename);
		$stmt->bindParam(':department', $department);
		

        // Execute statement
        $stmt->execute();
    }

    public function getAll()
    {
        $sql = 'SELECT * FROM Staff';

        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        $stmt->setFetchMode(\PDO::FETCH_CLASS, 'Itb\\Staff');

        $employees = $stmt->fetchAll();

        return $employees;
    }


    public function getOne($department)
    {
        $sql = 'SELECT * FROM staff WHERE department = :department';

        $stmt = $this->connection->prepare($sql);
        $stmt->bindParam(':employeename', $employeename);
		$stmt->bindParam(':department', $department);
	

        // Execute statement
        $stmt->execute();
        $stmt->setFetchMode(\PDO::FETCH_CLASS, 'Itb\\Staff');

        $employee = $stmt->fetch();

        return $employee;


    }
	 public function deleteOne($id)
    {
    
        $sql = 'DELETE FROM staff WHERE id = :id';
        $stmt = $this->connection->prepare($sql);

      
        $stmt->bindParam(':id', $id);

       
        $noError = $stmt->execute();

        
        return $noError;
    }

    public function deleteAll()
    {
        $sql = 'DELETE * FROM staff';

        $stmt = $this->connection->exec($sql);
    }





}