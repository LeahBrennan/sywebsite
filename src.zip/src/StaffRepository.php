<?php


namespace Itb;


class StaffRepository
{
    /**
     * @var \PDO
     */
    private $connection;

    public function __construct()
    {
        $db = new Database();
        $this->connection = $db->getConnection();
    }

    public function dropTable()
    {
        $sql = "DROP TABLE IF EXISTS staff";
        $this->connection->exec($sql);
    }

    public function createTable()
    {
        // drop table if it already exists
        // (removing all old data)
        $this->dropTable();

        $sql = "
            CREATE TABLE IF NOT EXISTS staff (
            employeename text
			position text,
			)
        ";

        $this->connection->exec($sql);
    }

    public function insert($employeename, $position)
    {
        // Prepare INSERT statement to SQLite3 file db
        $sql = 'INSERT INTO staff (employeename, position) 
			VALUES (:employeename, :position)';
        $stmt = $this->connection->prepare($sql);

        // Bind parameters to statement variables
        $stmt->bindParam(':employeename', $employeename);
		$stmt->bindParam(':position', $position);
		

        // Execute statement
        $stmt->execute();
    }

    public function getAll()
    {
        $sql = 'SELECT * FROM Staff';

        $stmt = $this->connection->prepare($sql);
        $stmt->execute();
        $stmt->setFetchMode(\PDO::FETCH_CLASS, 'Itb\\Staff');

        $employees = $stmt->fetchAll();

        return $employees;
    }


    public function getOne($position)
    {
        $sql = 'SELECT * FROM staff WHERE position = :position';

        $stmt = $this->connection->prepare($sql);
        $stmt->bindParam(':name', $name);
		$stmt->bindParam(':position', $position);
	

        // Execute statement
        $stmt->execute();
        $stmt->setFetchMode(\PDO::FETCH_CLASS, 'Itb\\Staff');

        $employee = $stmt->fetch();

        return $employee;


    }


    public function deleteAll()
    {
        $sql = 'DELETE * FROM staff';

        $stmt = $this->connection->exec($sql);
    }





}