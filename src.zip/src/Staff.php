<?php

namespace Itb;


class Staff
{

    private $employeename;
    private $department;

    public function getEmployeeName()
    {
        return $this->employeename;
    }

    /**
     * @param mixed $name
     */
    public function setEmployeeName($employeename)
    {
        $this->employeename = $employeename;
    }
	 public function getDepartment()
    {
        return $this->department;
    }

    /**
     * @param mixed $name
     */
    public function setDepartment($department)
    {
        $this->department = $department;
    }

	
	



}