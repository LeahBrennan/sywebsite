<?php

namespace Itb;


class Visitor
{
    private $employeename;
    private $position;

    /**
     * @return mixed
     */
    public function getEmployeeName()
    {
        return $this->employeename;
    }

    /**
     * @param mixed $name
     */
    public function setEmployeeName($employeename)
    {
        $this->employeename = $employeename;
    }
	 public function getPosition()
    {
        return $this->position;
    }

    /**
     * @param mixed $name
     */
    public function setPosition($position)
    {
        $this->position = $position;
    }

	
	



}