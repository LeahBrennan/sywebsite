<?php

namespace Itb;


class Visitor
{
 
	private $id;
	private $username;
    private $email;

    /**
     * @return mixed
     */
    public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $name
     */
    public function setId($id)
    {
        $this->id = $id;
    }
	 
    public function getUsername()
    {
        return $this->username;
    }

    /**
     * @param mixed $name
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }
	 public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param mixed $name
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

	



}