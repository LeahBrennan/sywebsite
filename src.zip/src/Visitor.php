<?php

namespace Itb;


class Visitor
{
 
	private $username;
    private $email;

    /**
     * @return mixed
     */

    public function getUsername()
    {
        return $this->username;
    }

    /**
     * @param mixed $name
     */
    public function setUsername($username)
    {
        $this->username = $username;
    }
	 public function getEmail()
    {
        return $this->email;
    }

    /**
     * @param mixed $name
     */
    public function setEmail($email)
    {
        $this->email = $email;
    }

	



}