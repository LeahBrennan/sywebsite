<?php


namespace Itb;
class MainController
{
  
    public function homeAction()
    {
        include __DIR__ . '/../views/home.php';
	
    }
    public function aboutAction()
    {
        include __DIR__ . '/../views/about.php';
    }
	public function sitemapAction()
	{
      include __DIR__ . '/../views/sitemap.php';
	}
	public function peopleAction()
	{
      include __DIR__ . '/../views/people.php';
	}
	public function shoppingAction()
	{
      include __DIR__ . '/../views/shopping.php';
	}
	public function staffloginAction()
	{
      include __DIR__ . '/../views/stafflogin.php';
	}
	public function adminloginAction()
	{
      include __DIR__ . '/../views/adminlogin.php';
	}
	public function signupAction()
	{
      include __DIR__ . '/../views/signup.php';
	}
	public function tablesAction()
	{
		include __DIR__ .  '/../views/tables.php';
	}
	public function tables2Action()
	{
		include __DIR__ .  '/../views/tables2.php';
	}
	public function addProductAction()
	{
		include __DIR__ . '/../views/addproduct.php';
	}
	public function addProductProcessAction()
	{
		include __DIR__ . '/../views/addProductProcess.php';
	}
	public function addEmployeeAction()
	{
		include __DIR__ . '/../views/addEmployee.php';
	}
	public function addEmployeeProcessAction()
	{
		include __DIR__ . '/../views/addEmployeeProcess.php';
	}
	public function editProductProcessAction()
	{
		include __DIR__ . '/../views/editProductProcess.php';
	}
	public function removeproductAdminAction($id)
	{
	$productRepository = new ProductRepository();
	$productRepository->deleteOneAdmin($id);
	include __DIR__ . '/../views/tables.php';
	}
	public function removeproductStaffAction($id)
	{
     $productRepository = new ProductRepository();
	 $productRepository->deleteOneStaff($id);
	 include __DIR__ . '/../views/tables.php';
	}
	
	public function removestaffAdminAction($id)
	{
	$staffRepository = new StaffRepository();
	$staffRepository->deleteOne($id);
	include __DIR__ . '/../views/tables.php';
	}
	public function updateProductAdminAction($id, $description, $price, $quantity)
	{
		$productRepository = new ProductRepository;
		$productRepository->update($id, $description, $price, $quantity);
		include __DIR__ . '/../views/editProductAdmin.php';
	}
	
     public function useremailAction()
	{
	 include __DIR__ . '/../views/processForm.php';
	}
	public function adlogAction()
	{
		include __DIR__ . '/../views/adminPage.php';
	}
    public function stafflogAction()
	{
		include __DIR__ . '/../views/staffPage.php';
	}


}


   
		
