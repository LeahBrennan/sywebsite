<?php

namespace Itb;

class WebApplication 
{

private $mainController;



public function __construct()
{
	$this->mainController = new MainController();
}
public function run()
{
$action = filter_input(INPUT_GET, 'action');

switch($action){
    case 'about':
        $this->mainController->aboutAction();
        break;
	case 'sitemap':
	     $this->mainController ->sitemapAction();
	     break;
    case 'people':
	     $this->mainController ->peopleAction();
		 break;
    case 'shopping':
	      $this->mainController ->shoppingAction();
		  break;
    case 'stafflogin':
	      $this->mainController ->staffloginAction();
		  break;
    case 'adminlogin':
	      $this->mainController ->adminloginAction();
		  break;
    case 'signup':
	      $this->mainController ->signupAction();
		  break;
	case 'tables':
	      $this->mainController ->tablesAction();
		  break;
    case 'tables2':
	      $this->mainController ->tables2Action();
		  break;
	case 'addproduct':
	     $this->mainController->addProductAction();
		 break;
    case 'addemployee':
	     $this->mainController->addEmployeeAction();
		 break;
	case 'addProductProcess':
	      $this->mainController->addProductProcessAction();
		  break;
	case 'addEmployeeProcess':
	      $this->mainController->addEmployeeProcessAction();
		  break;
    case 'removeproductadmin':
	      $id = filter_input(INPUT_GET, 'id');
	      $this->mainController -> removeproductAdminAction($id);
		  break;
	case 'removeproductstaff';
	      $id = filter_input(INPUT_GET,'id');
		  $this->mainController -> removeproductStaffAction($id);
		  break;
	case 'editProductProcess':
	      $id = filter_input(INPUT_GET,'id');
	      $this->mainController->editProductProcessAction();
		  break;
	case 'removestaff':
	      $id = filter_input(INPUT_GET, 'id');
	      $this->mainController-> removestaffAdminAction($id);
		  break;
    case 'useremail':
	      $this->mainController-> useremailAction();
		  break;
    case 'adlog':
	      $this->mainController-> adlogAction();
		  break;
    case 'stafflog';
	      $this-> mainController -> stafflogAction();
		  break;
   case 'updateProductAdmin':
          $id = filter_input(INPUT_GET, 'id');
          $this->mainController->updateProductAdminAction($id, $description, $price, $quantity);
          break;
    case 'home':
    default:
	      $this->mainController->homeAction();
	   
}
}
}
