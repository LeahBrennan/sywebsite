<?php

namespace Itb;

class WebApplication 
{
private $mainController;

public function __construct()
{
	$this->mainController = new MainController();
}

public function run()
{
$action = filter_input(INPUT_GET, 'action');

switch($action){
    case 'about':
        $this->mainController->aboutAction();
        break;
	case 'sitemap':
	     $this->mainController ->sitemapAction();
	     break;
    case 'people':
	     $this->mainController ->peopleAction();
		 break;
    case 'shopping':
	      $this->mainController ->shoppingAction();
		  break;
    case 'stafflogin':
	      $this->mainController ->staffloginAction();
		  break;
    case 'adminlogin':
	      $this->mainController ->adminloginAction();
		  break;
    case 'signup':
	      $this->mainController ->signupAction();
		  break;
		  case 'tables':
	      $this->mainController ->tablesAction();
		  break;
    case 'tables2':
	      $this->mainController ->tables2Action();
		  break;
    case 'removeproduct':
	      $this->mainController -> removeproductAction();
		  break;
	case 'updateproduct':
	      $this->mainController -> updateproductAction();
		  break;  
	case 'removestaff':
	      $this->mainController-> removestaffAction();
		  break;
    case 'updatestaff':
	      $this->mainController-> updatestaffAction();
		  break;
    case 'useremail':
	      $this->mainController-> useremailAction();
		  break;
		  
    case 'home':
    default:
	      $this->mainController->homeAction();
	   
}
}
}
