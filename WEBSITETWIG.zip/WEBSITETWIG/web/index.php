<?php

require_once __DIR__ . '/../vendor/autoload.php';

$app = new Itb\WebApplication;
$app ->run();

