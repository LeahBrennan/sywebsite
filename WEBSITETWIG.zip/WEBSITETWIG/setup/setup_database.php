<?php
require_once __DIR__ . '/../vendor/autoload.php';

use Itb\ProductRepository;
use Itb\VisitorRepository;
use Itb\StaffRepository;
use Itb\ShoppingCartRepository;

$productRepository = new ProductRepository();
$productRepository->dropTable();
$productRepository->createTable();
$productRepository->deleteAll();
$productRepository->insertProduct(Product $p);
$productRepository->getAll();
$productRepository->getOne($id);
$productRepository->editProduct($id);
$productRepository->deleteOneStaff($id);
$productRepository->deleteOneAdmin($id);
$productRepository->update($id, $description, $price, $quantity);

/*-------------------------------------------------------------------------*/

$visitorRepository = new VisitorRepository();
$visitorRepository->dropTable();
$visitorRepository->createTable();
$visitorRepository->insertVisitor(Visitor $v);
$visitorRepository->getAll();

/* ------------------------------------------------------------------------*/

$staffRepository = new StaffRepository();
$staffRepository->dropTable();
$staffRepository->createTable();
$staffRepository->insertStaff(Staff $s);
$staffRepository->getAll();
$staffRepository->getOne($id);
$staffRepository->deleteOne($id);
$staffRepository->deleteAll();

/*--------------------------------------------------------------------------*/

$shoppingcartRepository = new ShoppingCartRepository();
$shoppingcartRepository->dropTable();
$shoppingcartRepository->createTable();
$shoppingcartRepository->deleteAll();
$shoppingcartRepository->insertShop(Product $s);
$shoppingcartRepository->getAll();
$shoppingcartRepository->getOne($id);




