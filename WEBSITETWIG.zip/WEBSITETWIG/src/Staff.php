<?php

namespace Itb;


class Staff
{

    private $id;
	private $employeename;
    private $department;

	  public function getId()
    {
        return $this->id;
    }

    /**
     * @param mixed $name
     */
    public function setId($id)
    {
        $this->id= $id;
    }
    public function getEmployeeName()
    {
        return $this->employeename;
    }

    /**
     * @param mixed $name
     */
    public function setEmployeeName($employeename)
    {
        $this->employeename = $employeename;
    }
	 public function getDepartment()
    {
        return $this->department;
    }

    /**
     * @param mixed $name
     */
    public function setDepartment($department)
    {
        $this->department = $department;
    }

	
	



}