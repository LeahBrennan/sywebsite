<?php


namespace Itb;
class MainController
{
    private $twig;

    public function __construct($twig)
    {
        $this-> twig = $twig;
    }

    public function homeAction()
    {
        $template = 'home.html.twig';
        $argsArray = [
            'pageTitle' => 'Home'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }
    public function aboutAction()
    {
        $template = 'about.html.twig';
        $argsArray = [
            'pageTitle' => 'About'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
    }
	public function sitemapAction()
	{
        $template = 'sitemap.html.twig';
        $argsArray = [
            'pageTitle' => 'Sitemap'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
	}
	public function peopleAction()
	{
        $template = 'people.html.twig';
        $argsArray = [
            'pageTitle' => 'People'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
	}
	public function shoppingAction()
	{
        $template = 'shopping.html.twig';
        $argsArray = [
            'pageTitle' => 'Shopping'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
	}
	public function staffloginAction()
	{
        $template = 'stafflogin.html.twig';
        $argsArray = [
            'pageTitle' => 'StaffLogin'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
	}
	public function adminloginAction()
	{
        $template = 'adminlogin.html.twig';
        $argsArray = [
            'pageTitle' => 'AdminLogin'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
	}
	public function signupAction()
	{
        $template = 'signup.html.twig';
        $argsArray = [
            'pageTitle' => 'Signup'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
	}
	public function tablesAction()
	{
        $template = 'tables.html.twig';
        $argsArray = [
            'pageTitle' => 'Tables'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
	}
	public function tables2Action()
	{
        $template = 'tables2.html.twig';
        $argsArray = [
            'pageTitle' => 'Tables2'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
	}
	public function addProductAction()
	{
        $template = 'addproduct.html.twig';
        $argsArray = [
            'pageTitle' => 'AddProduct'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
	}
	public function addProductProcessAction()
	{
        $template = 'addProductProcess.html.twig';
        $argsArray = [
            'pageTitle' => 'AddProductProcess'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
	}
	public function addEmployeeAction()
	{
        $template = 'addEmployee.html.twig';
        $argsArray = [
            'pageTitle' => 'AddEmployee'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
	}
	public function addEmployeeProcessAction()
	{
        $template = 'addEmployeeProcess.html.twig';
        $argsArray = [
            'pageTitle' => 'AddEmployeeProcess'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
	}
	public function editProductProcessAction()
	{
        $template = 'editProductProcess.html.twig';
        $argsArray = [
            'pageTitle' => 'EditProductProcess'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
	}
	public function editStaffProcessAction()
	{
        $template = 'editStaffProcess.html.twig';
        $argsArray = [
            'pageTitle' => 'EditStaffProcess'
        ];
        $html = $this->twig->render($template, $argsArray);
        print $html;
	}
	public function removeproductAdminAction($id)
	{
	$productRepository = new ProductRepository();
	$productRepository->deleteOneAdmin($id);
	include __DIR__ . '/../views/tables.html.twig';
	}
	public function removeproductStaffAction($id)
	{
     $productRepository = new ProductRepository();
	 $productRepository->deleteOneStaff($id);
	 include __DIR__ . '/../views/tables.html.twig';
	}
	
	public function removestaffAdminAction($id)
	{
	$staffRepository = new StaffRepository();
	$staffRepository->deleteOne($id);
	include __DIR__ . '/../views/tables.html.twig';
	}
	public function updateProductAdminAction($id, $description, $price, $quantity)
	{
		$productRepository = new ProductRepository;
		$productRepository->update($id, $description, $price, $quantity);
		include __DIR__ . '/../views/editProductAdmin.html.twig';
	}
		public function updateProductStaffAction($id, $description, $price, $quantity)
	{
		$productRepository = new ProductRepository;
		$productRepository->update($id, $description, $price, $quantity);
		include __DIR__ . '/../views/editProductStaff.html.twig';
	}
		public function updateStaffAction($id, $employeename, $department)
	{
		$productRepository = new ProductRepository;
		$productRepository->update($id, $employeename, $department);
		include __DIR__ . '/../views/editStaff.html.twig';
	}
	
     public function useremailAction()
	{
	 include __DIR__ . '/../views/processForm.html.twig';
	}
	public function adlogAction()
	{
		include __DIR__ . '/../views/adminPage.html.twig';
	}
    public function stafflogAction()
	{
		include __DIR__ . '/../views/staffPage.html.twig';
	}
    public function setupAction()
    {
        include_once __DIR__.'/../setup/setupDatabase.php';
    }

}


   
		
