<?php 
require_once __DIR__ . '/../vendor/autoload.php';
 use Itb\Visitor;
 use Itb\VisitorRepository;
 
 $username = filter_input(INPUT_POST, 'username');
 $email = filter_input(INPUT_POST, 'email');
 
 
 $v =  new Visitor();
 
 $v-> setUsername($username);
 $v-> setEmail($email);
 
 $visitorRepository = new VisitorRepository();
 $visitorRepository->createTable();
 $visitorRepository->insertVisitor($v);
 
?>
<!doctype html>
<html lang="en">
<head>
    <title>Irish Women's Rugby</title>
    <meta charset="utf-8">
	
 <style>
<?php include 'css/style.css';?>
 </style>
	
</head>
<h1>Irish Women's Rugby</h1>
<ul>
<li><a href="/index.php">Home</a></li>
<li><a href="/index.php?action=about">About</a></li>
<li><a href ="/index.php?action=sitemap">Sitemap </a></li>
<li><a href = "/index.php?action=people">People</a></li>
<li><a href = "/index.php?action=shopping">Shopping</a></li>
<li><a href = "/index.php?action=stafflogin">Staff Login</a></li>
<li><a href = "/index.php?action=adminlogin">Admin Login</a></li>
<li><a href = "/index.php?action=signup">Sign-up</a></li>
</ul>
<?php

        echo 'You have entered' . $_POST["username"] . 'and' . $_POST["email"] ;

?>
<footer>
</footer>
</body>
</html>
