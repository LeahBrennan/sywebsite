<?php 
require_once __DIR__ . '/../vendor/autoload.php';
 use Itb\Visitor;
 use Itb\VisitorRepository;
 
 $username = filter_input(INPUT_POST, 'username');
 $email = filter_input(INPUT_POST, 'email');
 
 
 $v =  new Visitor();
 
 $v-> setUsername($username);
 $v-> setEmail($email);
 
 $visitorRepository = new VisitorRepository();
 $visitorRepository->createTable();
 $visitorRepository->insertVisitor($v);
 
?>
<!doctype html>
<html lang="en">
<head>
    <title>Irish Women's Rugby</title>
    <meta charset="utf-8">
	
 <style>
<?php include 'css/style.css';?>
 </style>
	
</head>
<h1><a class = "clickheader" href="/index.php">Irish Women's Rugby</a></h1>
<ul>
<li><a href="/index.php">Home</a></li>
<li><a href="/index.php?action=about">About</a></li>
<li><a href = "/index.php?action=people">People</a></li>
<li><a href = "/index.php?action=shopping">Shopping</a></li>
<li><a href = "/index.php?action=stafflogin">Staff Login</a></li>
<li><a href = "/index.php?action=adminlogin">Admin Login</a></li>
<li><a href = "/index.php?action=signup">Sign-up</a></li>
<li><a href ="/index.php?action=sitemap">Sitemap </a></li>
</ul>
<?php
$username = "";
$email = ""; 
$Err = "";

if($_SERVER["REQUEST_METHOD"] == "POST"){
    if(empty($_POST["username"]) && empty($_POST["email"])){
        echo $Err = "No information entered.<a href = \"/index.php?action=signup\">Return to sign-up</a>";
    }else{
	echo 'You have entered:' . $_POST["username"].   'and'   . $_POST["email"] ;
    }
}


?>
<footer>
</footer>
</body>
</html>
