<?php
require_once __DIR__ .'/../vendor/autoload.php';

use Itb\Product;
use Itb\ProductRepository;


$quantity = filter_input(INPUT_POST, 'quantity');
$description = filter_input(INPUT_, 'description');
$price = filter_input(INPUT_GET, 'price');



$p = new Product();

$p->setQuantity($quantity);
$p->setDescription($description);
$p->setPrice($price);

$productRepository = new ProductRepository();
$p->$productRepository->getOne($id);

$productRepository->update($p);
?>

<!doctype html>
<html lang="en">
<head>
    <title>Irish Women's Rugby</title>
    <meta charset="utf-8">
	
 <style>
<?php include 'css/style.css';?>
 </style>
	
</head>
<h1><a class = "clickheader" href="/index.php">Irish Women's Rugby</a></h1>
<ul>
<li><a href="/index.php">Home</a></li>
<li><a href="/index.php?action=about">About</a></li>
<li><a href = "/index.php?action=people">People</a></li>
<li><a href = "/index.php?action=shopping">Shopping</a></li>
<li><a href = "/index.php?action=stafflogin">Staff Login</a></li>
<li><a href = "/index.php?action=adminlogin">Admin Login</a></li>
<li><a href = "/index.php?action=signup">Sign-up</a></li>
<li><a href ="/index.php?action=sitemap">Sitemap </a></li>
</ul>
<?php
echo "Product inserted.<a href = \"/index.php?action=tables\">Return to admin page</a>";
?>

</html>
<footer>
</footer>
