<?php

$nameErr = "";
$name = "";
$pass = "predefined1";
$passErr = "";



if ($_SERVER["REQUEST_METHOD"] == "GET") {
    if (empty($_GET["name"])) {
        echo $nameErr = "No name entered";
		
    }
	<?php
	else {
        echo '<a href = "/index.php?action=tables2">Tables</a>'; 

    }
	?>
	
	<?php
	if ($pass == "predefined1")){
		echo '<a href = "/index.php?action=tables2">Tables</a>';
	}
	?>
	else{ 
		echo $passErr = "Invalid Password"; 
	
	}
	
}
