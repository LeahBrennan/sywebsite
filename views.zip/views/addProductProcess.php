<?php
require_once __DIR__ .'/../vendor/autoload.php';

use Itb\Product;
use Itb\ProductRepository;


$quantity = filter_input(INPUT_POST, 'quantity');
$description = filter_input(INPUT_POST, 'description');
$price = filter_input(INPUT_POST, 'price');


$p = new Product();

$p->setDescription($description);
$p->setPrice($price);
$p->setQuantity($quantity);

$productRepository = new ProductRepository();
$productRepository->createTable();

$productRepository->insertProduct($p);
?>

<!doctype html>
<html lang="en">
<head>
    <title>Irish Women's Rugby</title>
    <meta charset="utf-8">
	
 <style>
<?php include 'css/style.css';?>
 </style>
	
</head>
<h1>Irish Women's Rugby</h1>
<ul>
<li><a href="/index.php">Home</a></li>
<li><a href="/index.php?action=about">About</a></li>
<li><a href = "/index.php?action=people">People</a></li>
<li><a href = "/index.php?action=shopping">Shopping</a></li>
<li><a href = "/index.php?action=stafflogin">Staff Login</a></li>
<li><a href = "/index.php?action=adminlogin">Admin Login</a></li>
<li><a href = "/index.php?action=signup">Sign-up</a></li>
<li><a href ="/index.php?action=sitemap">Sitemap </a></li>
</ul>
<?php
echo "Product inserted.<a href = \"/index.php?action=tables\">Return to admin page</a>";
?>

</html>
<footer>
</footer>


