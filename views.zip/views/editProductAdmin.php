<!doctype html>
<html lang="en">
<head>
    <title>Irish Women's Rugby</title>
    <meta charset="utf-8">
	<style><?php include 'css/style.css';?></style>
</head>
<h1><a class = "clickheader" href="/index.php">Irish Women's Rugby</a></h1>
<ul>
<li><a href="/index.php">Home</a></li>
<li><a href="/index.php?action=about">About</a></li>
<li><a href = "/index.php?action=people">People</a></li>
<li><a href = "/index.php?action=shopping">Shopping</a></li>
<li><a href = "/index.php?action=stafflogin">Staff Login</a></li>
<li><a href = "/index.php?action=adminlogin">Admin Login</a></li>
<li><a href = "/index.php?action=signup">Sign-up</a></li>
<li><a href ="/index.php?action=sitemap">Sitemap </a></li>
</ul>

<body>
<form action ='/index.php?action=editProductProcess' method = 'get'>
    <h2>Update Product Form</h2>
	<br>
	ID: <input type = "number" name ="id&id=<?=$id?>">
	<br>
    Quantity: <input type="number" name="quantity&quantity=<?=$quantity?>"  min = "1" max ="100">
	<br>
	Description:<input type = "text" name= "description&description=<?=$description?>">
	<br> 
	Price:<input type = "number" name = "price&price=<?=$price?>" min ="1" step = "0.01">
	<br>
	
	<input type = "submit">
	<br>
	<input type = "reset">
	<br>
</form>



<footer>
</footer>
</body>
</html>