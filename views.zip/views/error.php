<!doctype html>
<html lang="en">
<head>
    <title>MGW - error page</title>
    <meta charset="utf-8">
</head>

<body>

<h1>error</h1>
<p>
    Sorry, the action requested cannot be found
</p>
<hr>

<p>
    <a href="index.php?action=index">(to home page)</a>
</p>
<p>
    <a href="index.php?action=about">(to about page)</a>
</p>

<footer>

</footer>
</body>
</html>