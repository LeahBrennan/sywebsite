<!doctype html>
<html lang="en">
<head>
    <title>Irish Women's Rugby</title>
	
    <meta charset="utf-8">
	<style><?php include 'css/style.css';?></style>
</head>
<h1><a class = "clickheader" href="/index.php">Irish Women's Rugby</a></h1>
<ul>
<li><a href="/index.php">Home</a></li>
<li><a href="/index.php?action=about">About</a></li>
<li><a href = "/index.php?action=people">People</a></li>
<li><a href = "/index.php?action=shopping">Shopping</a></li>
<li><a href = "/index.php?action=stafflogin">Staff Login</a></li>
<li><a href = "/index.php?action=adminlogin">Admin Login</a></li>
<li><a href = "/index.php?action=signup">Sign-up</a></li>
<li><a href ="/index.php?action=sitemap">Sitemap </a></li>
</ul>

<body>

<p>
    Shopping
</p>
<hr>

<p>
    
</p>

<footer>
</footer>
</body>
</html>