<!doctype html>
<html lang="en">
<head>
    <title>Irish Women's Rugby</title>
	
    <meta charset="utf-8">
<style><?php include 'css/style.css';?></style>
</head>
<h1><a class = "clickheader" href="/index.php">Irish Women's Rugby</a></h1>
<ul>
<li><a href="/index.php">Home</a></li>
<li><a href="/index.php?action=about">About</a></li>
<li><a href = "/index.php?action=people">People</a></li>
<li><a href = "/index.php?action=shopping">Shopping</a></li>
<li><a href = "/index.php?action=stafflogin">Staff Login</a></li>
<li><a href = "/index.php?action=adminlogin">Admin Login</a></li>
<li><a href = "/index.php?action=signup">Sign-up</a></li>
<li><a href ="/index.php?action=sitemap">Sitemap </a></li>
</ul>
<body>
<h2>Products</h2>
<table>
<?php 
require_once __DIR__ . '/../vendor/autoload.php';
 use Itb\Product;
 use Itb\ProductRepository;
 
$productRepository = new ProductRepository();
$products = $productRepository ->getAll();
foreach($products as $product){
	$id = $product ->getId();
?>
<tr>
    <th>Id</th>
	<th>Quantity</th>
	<th>Description</th>
	<th>Price</th>
	<th>Remove</th>
	<th>Update</th>
</tr>
<tr>
    <td><?= $product->getId() ?></td>
	<td><?= $product->getQuantity() ?></td>
	<td><?= $product->getDescription() ?></td>
	<td><?= $product->getPrice() ?></td>
	<td><a href = "index.php?action=removeproduct" class ="consistent">Remove</div></a></td>
	<td><a class = "consistent" href = "index.php?action=updateproduct">Update</a></td>
</tr>

<?php
}
?>
</table>
        <h2>Visitors</h2>
<table>
<?php 
require_once __DIR__ . '/../vendor/autoload.php';
 use Itb\Visitor;
 use Itb\VisitorRepository;
 
$visitorRepository = new VisitorRepository();
$visitors = $visitorRepository ->getAll();
foreach($visitors as $visitor){
	$username = $visitor ->getUsername();
?>
<tr>
    
	<th>Username</th>
	<th>Email</th>
</tr>
<tr>
    <td><?= $visitor ->getUsername() ?></td>
	<td><?= $visitor ->getEmail() ?></td>
	
	
</tr>
<?php
}
?>
</table>
<hr>		          
<a  class = "consistent" href = "index.php?action=addproduct">Add a Product to the Product table</a>
	
<footer>
</footer>
</body>
</html>