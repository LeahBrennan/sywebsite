<!doctype html>
<html lang="en">
<head>
    <title>Irish Ladies Rugby</title>
	
    <meta charset="utf-8">
<style><?php include 'css/style.css';?></style>
</head>
<h1>Irish Women's Rugby</h1>
<ul>
<li><a href="/index.php">Home</a></li>
<li><a href="/index.php?action=about">About</a></li>
<li><a href ="/index.php?action=sitemap">Sitemap </a></li>
<li><a href = "/index.php?action=people">People</a></li>
<li><a href = "/index.php?action=shopping">Shopping</a></li>
<li><a href = "/index.php?action=stafflogin">Staff Login</a></li>
<li><a href = "/index.php?action=adminlogin">Admin Login</a></li>
<li><a href = "/index.php?action=signup">Sign-up</a></li>
</ul>
<body>
<h2>Products</h2>
<table>
<?php 
require_once __DIR__ . '/../vendor/autoload.php';
 use Itb\Product;
 use Itb\ProductRepository;
 
$productRepository = new ProductRepository();
$products = $productRepository ->getAll();

foreach($products as $product){
	$id = $this->getId();
?>
<tr>
    <th>Id</th>
	<th>Quantity</th>
	<th>Description</th>
	<th>Price</th>
</tr>
<tr>
    <td><?= $this ->getId() ?></td>
	<td><?= $this->getQuantity() ?></td>
	<td><?= $this ->getDescription() ?></td>
	<td><?= $this ->getPrice() ?></td>
	<td><a href = "/index.php?action=removeproduct">Remove</a></td>
	<td><a href = "/index.php?action=updateproduct">Update</a></td>
</tr>
<?php
}
?>
</table>
        <h2>Staff</h2>
<table>
<?php 
require_once __DIR__ . '/../vendor/autoload.php';
 use Itb\Staff;
 use Itb\StaffRepository;
 
$staffRepository = new StaffRepository();
$employees = $staffRepository ->getAll();

foreach($employees as $employee)
{
	$employeename = $this ->getEmployeeName();
?>
<tr>
    
	<th>Name</th>
	<th>Position</th>
	
</tr>
<tr>
    <td><?= $this ->getEmployeeName() ?></td>
	<td><?= $this ->getDepartment() ?></td>
	<td><a href = "index.php?action=removestaff">Remove</a></td>
	<td><a href = "index.php?action=updatestaff">Update</a></td>
</tr>
<?php
}
?>
</table>
		          

	
<footer>
</footer>
</body>
</html>