<!doctype html>
<html lang="en">
<head>
    <title>Irish Ladies Rugby</title>
	
    <meta charset="utf-8">
<style><?php include 'css/style.css';?></style>
</head>
<h1>Irish Women's Rugby</h1>
<ul>
<li><a href="/index.php">Home</a></li>
<li><a href="/index.php?action=about">About</a></li>
<li><a href ="/index.php?action=sitemap">Sitemap </a></li>
<li><a href = "/index.php?action=people">People</a></li>
<li><a href = "/index.php?action=shopping">Shopping</a></li>
<li><a href = "/index.php?action=stafflogin">Staff Login</a></li>
<li><a href = "/index.php?action=adminlogin">Admin Login</a></li>
<li><a href = "/index.php?action=signup">Sign-up</a></li>
</ul>
<body>
<h2>Products</h2>
<table>
<?php 
foreach($products as $product){
	$id = $product ->getId();
?>
<tr>
    <th>Id</th>
	<th>Quantity</th>
	<th>Name</th>
	<th>Description</th>
	<th>Price</th>
</tr>
<tr>
    <td><?= $product ->getId() ?></td>
	<td><?= $product ->getQuantity() ?></td>
	<td><?= $product ->getName() ?></td>
	<td><?= $product ->getDescription() ?></td>
	<td><?= $product ->getPrice() ?></td>
	<td><a href = "index.php?action=removeproduct">Remove</a></td>
	<td><a href = "index.php?action=updateproduct">Update</a></td>
</tr>
<?php
}
?>
</table>
        <h2>Staff</h2>
<table>
<?php 
foreach($employee as $employees){
	$id = $employee ->getId();
?>
<tr>
    
	<th>Name</th>
	<th>Salary</th>
	<th>Hiredate</th>
</tr>
<tr>
    <td><?= $employee ->getName() ?></td>
	<td><?= $employee ->getSalary() ?></td>
	<td><?= $employee ->getHiredate() ?></td>
	
	<td><a href = "index.php?action=removestaff">Remove</a></td>
	<td><a href = "index.php?action=updatestaff">Update</a></td>
</tr>
<?php
}
?>
</table>
		          

	
<footer>
</footer>
</body>
</html>