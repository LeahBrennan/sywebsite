
<!doctype html>
<html lang="en">
<head>
    <title>Irish Ladies Rugby</title>
    <meta charset="utf-8">
	<style><?php include 'css/style.css';?></style>
</head>
<h1>Irish Women's Rugby</h1>
<ul>
<li><a href="/index.php">Home</a></li>
<li><a href="/index.php?action=about">About</a></li>
<li><a href ="/index.php?action=sitemap">Sitemap </a></li>
<li><a href = "/index.php?action=people">People</a></li>
<li><a href = "/index.php?action=shopping">Shopping</a></li>
<li><a href = "/index.php?action=stafflogin">Staff Login</a></li>
<li><a href = "/index.php?action=adminlogin">Admin Login</a></li>
<li><a href = "/index.php?action=signup">Sign-up</a></li>
</ul>


<body>
<form action ='staffPage.php' method = 'get'>
    Staff Login:
	<br>
    Name: <input type="text" name="name">
	<br>
	Password: <input type = "text" name ="password">
	<br>
	<input type = "submit">
	<br>
	<input type = "reset">
</form>



<footer>
</footer>
</body>
</html>