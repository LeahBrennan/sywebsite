<!doctype html>
<html lang="en">
<head>
    <title>Irish Ladies Rugby</title>
    <meta charset="utf-8">
	<style><?php include 'css/style.css';?></style>
</head>
<h1>Irish Women's Rugby</h1>
<ul>
<li><a href="/index.php">Home</a></li>
<li><a href="/index.php?action=about">About</a></li>
<li><a href ="/index.php?action=sitemap">Sitemap </a></li>
<li><a href = "/index.php?action=people">People</a></li>
<li><a href = "/index.php?action=shopping">Shopping</a></li>
<li><a href = "/index.php?action=stafflogin">Staff Login</a></li>
<li><a href = "/index.php?action=adminlogin">Admin Login</a></li>
<li><a href = "/index.php?action=signup">Sign-up</a></li>
</ul>
</html>

<?php

  $usr = "admin";
  $psw = "admin";
  $username = '$_POST[username]';
  $password = '$_POST[password]';


  if (($_POST['name']=="admin" && $_POST['password']=="admin")) {
    echo '<a href = "index.php?action=tables">Tables- Edit Staff/Product Tables</a>';
   
  }
    else {
      echo "Invalid Username and/or password. Please click the link in the navbar to attempt to sign-in again";
    }
    ?>
	


